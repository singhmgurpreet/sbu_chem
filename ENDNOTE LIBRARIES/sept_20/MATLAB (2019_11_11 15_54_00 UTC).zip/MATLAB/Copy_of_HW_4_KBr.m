clear all
data = dlmread('KBr.csv',',');
x_data_raw = data(:,1);
y_data_raw = data(:,2);
for i = 3:numel(x_data_raw)-2
    x_data(i) = mean(x_data_raw(i-2:i+2));
    y_data(i) = mean(y_data_raw(i-2:i+2));
end
datapoints_1 = numel(x_data);
dxaxis = x_data(2:datapoints_1-1);
for i = 2:datapoints_1-1;
    dyaxis(i-1) = ((y_data(i+1)-y_data(i-1))/(x_data(i+1)-x_data(i-1)));
end
datapoints_2 = numel(dxaxis);
dx_2_axis = dxaxis(2:datapoints_2-1);
for i = 2:datapoints_2-1;
    dy_2_axis(i-1) = ((dyaxis(i+1)-dyaxis(i-1))/(dxaxis(i+1)-dyaxis(i-1)));
end
plot(x_data,y_data,'k',dxaxis,dyaxis.*0.05,'r',dx_2_axis,dy_2_axis);
i_thr = 175;
dy_sign = sign(dyaxis);
for i = 1:numel(dyaxis)-1;
        if  y_data(i)>i_thr && dy_sign(i) == 1 && dy_sign(i+1) == -1%% && dy_2_axis(i) > dy_2_axis(i+1) 
            peak_loc(i+1) = 1;
        elseif y_data(i)>i_thr && dy_sign(i) == 0;
            peak_loc(i) = 1;
        else 
            peak_loc(i+1) = 0;
        end
end
k = find(peak_loc);
for i = 1:numel(k);
    scatter_x(i) = x_data(k(i));
    scatter_y(i) = y_data(k(i));
end
hold on
scatter(scatter_x,scatter_y,60,'k');
[pks,loc] = findpeaks(y_data,x_data,'MinPeakHeight',190);
scatter(loc,pks,'+r');
fprintf('Script Finished.\n');