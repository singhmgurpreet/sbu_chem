clear all
data = dlmread('HCl-IR.csv',',');
x_data = data(:,1);
y_data = data(:,2);
datapoints_1 = numel(x_data);
dxaxis = x_data(2:datapoints_1-1);
for i = 2:datapoints_1-1
    dyaxis(i-1) = ((y_data(i+1)-y_data(i-1))/(x_data(i+1)-x_data(i-1)));
end
datapoints_2 = numel(dxaxis);
dx_2_axis = dxaxis(2:datapoints_2-1);
for i = 2:datapoints_2-1;
    dy_2_axis(i-1) = ((dyaxis(i+1)-dyaxis(i-1))/(dxaxis(i+1)-dyaxis(i-1)));
end
y_data_2 = y_data(2:datapoints_1-1);
dyaxis.',;
dyaxis = dyaxis(:,1).*y_data_2(:,1);
plot(x_data,y_data,'k',dxaxis,dyaxis(2:datapoints_1-1),'r',dx_2_axis,dy_2_axis*100);
i_thr = 0.0012;
dy_sign = sign(dyaxis);
for i = 1:numel(dyaxis)-1;
    if y_data(i)>i_thr;
        if  dy_sign(i) == 1 & dy_sign(i+1) == -1;
            peak_loc(i+1) = 1;
        else 
            peak_loc(i+1) = 0;
        end
    else
        peak_loc(i) = 0;
    end
end
k = find(peak_loc);
for i = 1:numel(k);
    scatter_x(i) = x_data(k(i));
    scatter_y(i) = y_data(k(i));
end
hold on
scatter(scatter_x,scatter_y);
fprintf('Script Finished.\n');